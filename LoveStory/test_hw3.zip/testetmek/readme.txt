Run with following command:
> python3 comp.py "path of bin folder"